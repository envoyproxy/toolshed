"""Macro wrapper for the `xcodeproj` rule."""

load("@bazel_skylib//lib:sets.bzl", "sets")
load(":bazel_labels.bzl", "bazel_labels")
load(":logging.bzl", "warn")
load(":project_options.bzl", _default_project_options = "project_options")
load(":top_level_target.bzl", "top_level_target")
load(":xcode_schemes.bzl", "focus_schemes", "unfocus_schemes")
load(":xcodeproj_rule.bzl", "bwb_xcodeproj", "bwx_xcodeproj")
load(":xcodeproj_runner.bzl", "xcodeproj_runner")

def xcodeproj(
        *,
        name,
        adjust_schemes_for_swiftui_previews = True,
        archived_bundles_allowed = None,
        associated_extra_files = {},
        bazel_path = "bazel",
        build_mode = "bazel",
        config = "rules_xcodeproj",
        extra_files = [],
        focused_targets = [],
        install_directory = None,
        ios_device_cpus = "arm64",
        ios_simulator_cpus = None,
        minimum_xcode_version = None,
        post_build = None,
        pre_build = None,
        project_name = None,
        project_options = None,
        scheme_autogeneration_mode = "auto",
        schemes = [],
        top_level_targets,
        tvos_device_cpus = "arm64",
        tvos_simulator_cpus = None,
        unfocused_targets = [],
        watchos_device_cpus = "arm64_32",
        watchos_simulator_cpus = None,
        **kwargs):
    """Creates an `.xcodeproj` file in the workspace when run.

    This is a wrapper macro for the
    [actual `xcodeproj` rule](../xcodeproj/internal/xcodeproj_rule.bzl), which
    can't be used directly. All public API is documented below. The `kwargs`
    argument will pass forward values for globally available attributes (e.g.
    `visibility`, `features`, etc.) to the underlying rule.

    **EXAMPLE**

    ```starlark
    xcodeproj(
        name = "xcodeproj",
        project_name = "App",
        tags = ["manual"],
        top_level_targets = [
            top_level_target(":App", target_environments = ["device", "simulator"]),
            ":Tests",
        ],
    )
    ```

    Args:
        name: A unique name for this target.
        adjust_schemes_for_swiftui_previews: Optional. Whether to adjust schemes
            in BwB mode to explicitly include transitive dependencies that are
            able to run SwiftUI Previews. For example, this changes a scheme
            for an single application target to also include any app clip, app
            extension, framework, or watchOS app dependencies. Defaults to
            `True`.
        archived_bundles_allowed: This argument is deprecated and is now a
            no-op. It will be removed in a future release. Adjust the setting of
            `--define=apple.experimental.tree_artifact_outputs` on
            `build:rules_xcodeproj` in your `.bazelrc` or `xcodeproj.bazelrc`
            file.
        associated_extra_files: Optional. A `dict` of files to be added to the
            project. The key is a `string` value representing the label of the
            target the files should be associated with, and the value is a
            `list` of `File`s. These files won't be added to the project if the
            target is unfocused.
        bazel_path: Optional. The path the `bazel` binary or wrapper script. If
            the path is relative it will be resolved using the `PATH`
            environment variable (which is set to
            `/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin` in
            Xcode). If you want to specify a path to a workspace-relative
            binary, you must prepend the path with `./` (e.g. `"./bazelw"`).
        build_mode: Optional. The build mode the generated project should use.

            If this is set to `"xcode"`, the project will use the Xcode build
            system to build targets. Generated files and unfocused targets (see
            the `focused_targets` and `unfocused_targets` arguments) will be
            built with Bazel.

            If this is set to `"bazel"`, the project will use Bazel to build
            targets, inside of Xcode. The Xcode build system still unavoidably
            orchestrates some things at a high level.
        config: Optional. The Bazel config to use when generating the project or
            invoking `bazel` inside of Xcode. This is the basename of multiple
            configs. For example, if this is set to `"projectx_xcodeproj"`, then
            the following configs will be available for you to adjust in your
            `.bazelrc` file: `projectx_xcodeproj`,
            `projectx_xcodeproj_generator`, `projectx_xcodeproj_indexbuild`, and
            `projectx_xcodeproj_swiftuipreviews`.

            See the [usage guide](usage.md#bazel-configs) for more information
            on adjusting Bazel configs.
        extra_files: Optional. A `list` of extra `File`s to be added to the
            project.
        focused_targets: Optional. A `list` of target labels as `string` values.
            If specified, only these targets will be included in the generated
            project; all other targets will be excluded, as if they were
            listed explicitly in the `unfocused_targets` argument. The labels
            must match transitive dependencies of the targets specified in the
            `top_level_targets` argument.
        install_directory: Optional. The directory where the generated project
            will be written to. The path is relative to the workspace root.
            Defaults to the directory that the `xcodeproj` target is declared
            in (e.g. if the `xcodeproj` target is declared in `//foo/bar:BUILD`
            then the default value is `"foo/bar"`). Use `""` to have the project
            generated in the workspace root.
        ios_device_cpus: Optional. The value to use for `--ios_multi_cpus` when
            building the transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"device"`
            `target_environment`.

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"device"`
            `target_environment`, even if they aren't iOS targets.
        ios_simulator_cpus: Optional. The value to use for `--ios_multi_cpus`
            when building the transitive dependencies of the targets specified
            in the `top_level_targets` argument with the `"simulator"`
            `target_environment`.

            If no value is specified, it defaults to the simulator cpu that goes
            with `--host_cpu` (i.e. `sim_arm64` on Apple Silicon and `x86_64` on
            Intel).

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"simulator"`
            `target_environment`, even if they aren't iOS targets.
        minimum_xcode_version: Optional. The minimum Xcode version that the
            generated project supports. Newer Xcode versions can support newer
            features, so setting this to the highest value you can will enable
            the most features. The value is the dot separated version number
            (e.g. "13.4.1", "14", "14.1"). Defaults to whichever version of
            Xcode that Bazel uses during project generation.
        post_build: The text of a script that will be run after the build. For
            example: `./post-build.sh`, `"$SRCROOT/post-build.sh"`.

            The script will be run in Bazel's execution root, so you probably
            want to change to the `$SRCROOT` directory in the script.

            Currently this script will be run as part of Index Build. If you
            don't want that (which is probably the case), you should add a check
            to ensure `$ACTION == build`.
        pre_build: The text of a script that will be run before the build. For
            example: `./pre-build.sh`, `"$SRCROOT/pre-build.sh"`.

            The script will be run in Bazel's execution root, so you probably
            want to change to the `$SRCROOT` directory in the script.

            Currently this script will be run as part of Index Build. If you
            don't want that (which is probably the case), you should add a check
            to ensure `$ACTION == build`.
        project_name: Optional. The name to use for the `.xcodeproj` file. If
            not specified, the value of the `name` argument is used.
        project_options: Optional. A value returned by `project_options`.
        scheme_autogeneration_mode: Optional. Specifies how Xcode schemes are
            automatically generated.

            - `auto`: If no custom schemes are specified, via `schemes`, an
              Xcode scheme will be created for every buildable target. If custom
              schemes are provided, no autogenerated schemes will be created.

            - `none`: No schemes are automatically generated.

            - `all`: A scheme is generated for every buildable target even if
              custom schemes are provided.
        schemes: Optional. A `list` of values returned by
            `xcode_schemes.scheme`. Target labels listed in the schemes need to
            be from the transitive dependencies of the targets specified in the
            `top_level_targets` argument. This and the
            `scheme_autogeneration_mode` argument together customize how
            schemes for those targets are generated.
        top_level_targets: A `list` of a list of top-level targets. Each target
            can be specified as either a `Label` (or label-like `string`), a
            value returned by `top_level_target`, or a value returned by
            `top_level_targets`.
        tvos_device_cpus: Optional. The value to use for `--tvos_cpus` when
            building the transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"device"`
            `target_environment`.

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"device"`
            `target_environment`, even if they aren't tvOS targets.
        tvos_simulator_cpus: Optional. The value to use for `--tvos_cpus` when
            building the transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"simulator"`
            `target_environment`.

            If no value is specified, it defaults to the simulator cpu that goes
            with `--host_cpu` (i.e. `sim_arm64` on Apple Silicon and `x86_64` on
            Intel).

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"simulator"`
            `target_environment`, even if they aren't tvOS targets.
        unfocused_targets: Optional. A `list` of target labels as `string`
            values. Any targets in the transitive dependencies of the targets
            specified in the `top_level_targets` argument with a matching
            label will be excluded from the generated project. This overrides
            any targets specified in the `focused_targets` argument.
        watchos_device_cpus: Optional. The value to use for `--watchos_cpus`
            when building the transitive dependencies of the targets specified
            in the `top_level_targets` argument with the `"device"`
            `target_environment`.

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"device"`
            `target_environment`, even if they aren't watchOS targets.
        watchos_simulator_cpus: Optional. The value to use for `--watchos_cpus`
            when building the transitive dependencies of the targets specified
            in the `top_level_targets` argument with the `"simulator"`
            `target_environment`.

            If no value is specified, it defaults to the simulator cpu that goes
            with `--host_cpu` (i.e. `arm64` on Apple Silicon and `x86_64` on
            Intel).

            **Warning:** Changing this value will affect the Starlark transition
            hash of all transitive dependencies of the targets specified in the
            `top_level_targets` argument with the `"simulator"`
            `target_environment`, even if they aren't watchOS targets.
        **kwargs: Additional arguments to pass to the underlying `xcodeproj`
            rule specified by `xcodeproj_rule`.
    """
    testonly = kwargs.pop("testonly", True)

    if archived_bundles_allowed != None:
        warn("""\
`archived_bundles_allowed` is deprecated and is now a no-op. It will be \
removed in a future release. Adjust the setting of \
`--define=apple.experimental.tree_artifact_outputs` on `build:rules_xcodeproj` \
in your `.bazelrc` or `xcodeproj.bazelrc` file.""")

    # Apply defaults
    if not bazel_path:
        bazel_path = "bazel"
    if not build_mode:
        build_mode = "xcode"
    if install_directory == None:
        install_directory = native.package_name()
    if not project_name:
        project_name = name
    if not project_options:
        project_options = _default_project_options()

    if not top_level_targets:
        fail("`top_level_targets` cannot be empty.")

    actual_top_level_targets = []
    for target in top_level_targets:
        if type(target) == "string":
            actual_top_level_targets.append(top_level_target(target))
        elif type(target) == "list":
            actual_top_level_targets.extend(target)
        else:
            actual_top_level_targets.append(target)

    top_level_device_targets = [
        top_level_target.label
        for top_level_target in actual_top_level_targets
        if sets.contains(top_level_target.target_environments, "device")
    ]
    top_level_simulator_targets = [
        top_level_target.label
        for top_level_target in actual_top_level_targets
        if sets.contains(top_level_target.target_environments, "simulator")
    ]

    focused_targets = [
        bazel_labels.normalize(t)
        for t in focused_targets
    ]
    unfocused_targets = [
        bazel_labels.normalize(t)
        for t in unfocused_targets
    ]

    owned_extra_files = {}
    for label, files in associated_extra_files.items():
        for f in files:
            owned_extra_files[f] = bazel_labels.normalize(label)

    schemes_json = None
    if schemes:
        if unfocused_targets:
            schemes = unfocus_schemes(
                schemes = schemes,
                unfocused_targets = unfocused_targets,
            )
        if focused_targets:
            schemes = focus_schemes(
                schemes = schemes,
                focused_targets = focused_targets,
            )
        schemes_json = json.encode(schemes)

    generator_name = "{}.generator".format(name)

    is_fixture = kwargs.pop("is_fixture", False)

    xcodeproj_rule = kwargs.pop("xcodeproj_rule", None)
    if not xcodeproj_rule:
        if build_mode == "bazel":
            xcodeproj_rule = bwb_xcodeproj
        else:
            xcodeproj_rule = bwx_xcodeproj

    tags = kwargs.pop("tags", [])

    # The generator should always have its config applied, so add `manual` to
    # the tag to prevent accidental building with `//...`
    generator_tags = list(tags)
    if "manual" not in generator_tags:
        generator_tags.append("manual")

    xcodeproj_rule(
        name = generator_name,
        adjust_schemes_for_swiftui_previews = (
            adjust_schemes_for_swiftui_previews
        ),
        build_mode = build_mode,
        bazel_path = bazel_path,
        config = config,
        focused_targets = focused_targets,
        install_directory = install_directory,
        ios_device_cpus = ios_device_cpus,
        ios_simulator_cpus = ios_simulator_cpus,
        minimum_xcode_version = minimum_xcode_version,
        owned_extra_files = owned_extra_files,
        post_build = post_build,
        pre_build = pre_build,
        project_name = project_name,
        project_options = project_options,
        runner_label = bazel_labels.normalize(name),
        scheme_autogeneration_mode = scheme_autogeneration_mode,
        schemes_json = schemes_json,
        tags = generator_tags,
        testonly = testonly,
        top_level_device_targets = top_level_device_targets,
        top_level_simulator_targets = top_level_simulator_targets,
        tvos_device_cpus = tvos_device_cpus,
        tvos_simulator_cpus = tvos_simulator_cpus,
        unfocused_targets = unfocused_targets,
        unowned_extra_files = extra_files,
        watchos_device_cpus = watchos_device_cpus,
        watchos_simulator_cpus = watchos_simulator_cpus,
        **kwargs
    )

    xcodeproj_runner(
        name = name,
        bazel_path = bazel_path,
        config = config,
        is_fixture = is_fixture,
        project_name = project_name,
        tags = tags,
        testonly = testonly,
        xcodeproj_target = bazel_labels.normalize(generator_name),
        visibility = kwargs.get("visibility"),
    )
