.. _api_files:

####################
API Reference: Files
####################

**********
File: hs.h
**********

.. doxygenfile:: hs.h

*****************
File: hs_common.h
*****************

.. doxygenfile:: hs_common.h

******************
File: hs_compile.h
******************

.. doxygenfile:: hs_compile.h

******************
File: hs_runtime.h
******************

.. doxygenfile:: hs_runtime.h
