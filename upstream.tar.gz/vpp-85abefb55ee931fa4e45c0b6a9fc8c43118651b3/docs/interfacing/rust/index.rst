.. _rustvpp:

===============
Rust api client
===============

The VPP Rust API client is in alpha stage
You can read more in `this blog post <https://dev.to/felixfaisal/rust-vpp-api-bindings-lfx-mentorship-project-2g8p>`_
