.. _cvpp:

============
C api client
============

You can find a good example on how to build a binary API client in C here :

`src/vpp-api/vapi/vapi_c_test.c <__REPOSITORY_URL__/src/vpp-api/vapi/vapi_c_test.c>`_

