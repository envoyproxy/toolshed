.. _automatingthedeployment:

.. toctree::

Automating VPP deployment
__________________________



In order to make the VPP deployment easier inside AWS and Azure, we have created two different Terraform scripts, compatibles with both Public Cloud Provider. These scripts allow to automate the deployment of the resources. `Here you can find the scripts anf further information <https://github.com/francescospinelli94/Automating-Deployment-VPP>`_.


