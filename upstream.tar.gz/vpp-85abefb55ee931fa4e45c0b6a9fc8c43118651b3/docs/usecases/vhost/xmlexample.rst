.. _xmlexample01:

The XML File
------------

An example of a file that could be used with the virsh create command.

.. literalinclude:: iperf-vm.xml
   :language: XML
   :emphasize-lines: 5-9, 42-49, 74-81

