.. _vhost:

VPP with Virtual Machines
=========================
This chapter will describe how to use FD.io VPP with virtual machines. We describe
how to create Vhost port with VPP and how to connect them to VPP. We will also discuss
some limitations of Vhost.

.. toctree::

    vhost
    vhost02
    vhost03
    vhost04
    vhost05
    xmlexample

