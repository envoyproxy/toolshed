.. _release_notes:

Release notes
=============

.. toctree::
    :maxdepth: 2

    v25.10
    v25.06
    v25.02
    v24.10
    past
