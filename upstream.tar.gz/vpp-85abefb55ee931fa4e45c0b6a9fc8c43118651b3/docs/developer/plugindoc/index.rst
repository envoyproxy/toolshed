.. _add_new_plugin:

==============================
Adding a new plugin or feature
==============================


.. toctree::
    :maxdepth: 2

    add_plugin
    sample_plugin_doc
    handoffdemo
