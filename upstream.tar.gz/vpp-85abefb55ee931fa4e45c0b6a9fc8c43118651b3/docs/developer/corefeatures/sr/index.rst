.. _corefeature_sr:

===============
Segment routing
===============

.. toctree::
    :maxdepth: 1

    sr_doc
    sr_localsid
    sr_mpls
    sr_policy
    sr_steering