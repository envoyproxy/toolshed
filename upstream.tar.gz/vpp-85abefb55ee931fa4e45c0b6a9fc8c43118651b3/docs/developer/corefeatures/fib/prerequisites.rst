.. _prerequisites:

Prerequisites
-------------

This section describes some prerequisite topics and nomenclature that are
foundational to understanding the FIB architecture.

.. toctree::

   graphs
   prefixes
