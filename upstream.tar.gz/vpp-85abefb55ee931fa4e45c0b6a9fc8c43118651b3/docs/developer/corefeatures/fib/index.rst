.. _fib20:

The FIB
===========================================

This describe the FIB (Forwarding information base) implementation :
Hierarchical, Protocol, Independent

.. toctree::

   prerequisites
   thedatamodel
   tunnels
   mplsfib
   multicast
   debugging
   fastconvergence
   scale
   barnacles
   hacking
   missing
