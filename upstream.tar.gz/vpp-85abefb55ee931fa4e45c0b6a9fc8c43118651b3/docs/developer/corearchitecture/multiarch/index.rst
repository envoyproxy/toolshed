.. _multiarch:

Multi-architecture support
==========================

This reference guide describes how to use the vpp multi-architecture support scheme

.. toctree::
   :maxdepth: 1

   nodefns
   arbfns
