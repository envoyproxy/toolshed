.. _corearchitecture:

=================
Core Architecture
=================

.. toctree::
    :maxdepth: 1

    softwarearchitecture
    infrastructure
    vlib
    vnet
    featurearcs
    buffer_metadata
    multiarch/index
    bihash
    buildsystem/index
    multi_thread

