/*
 *------------------------------------------------------------------
 * vxlan_gbp_api.c - vxlan gbp api
 *
 * Copyright (c) 2018 Cisco and/or its affiliates.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at:
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *------------------------------------------------------------------
 */

#include <vnet/vnet.h>
#include <vlibmemory/api.h>

#include <vnet/interface.h>
#include <vnet/api_errno.h>
#include <vnet/feature/feature.h>
#include <vnet/vxlan-gbp/vxlan_gbp.h>
#include <vnet/fib/fib_table.h>
#include <vnet/ip/ip_types_api.h>
#include <vnet/format_fns.h>

#include <vxlan-gbp/vxlan_gbp.api_enum.h>
#include <vxlan-gbp/vxlan_gbp.api_types.h>

#define REPLY_MSG_ID_BASE msg_id_base
#include <vlibapi/api_helper_macros.h>

static u16 msg_id_base;

static void
  vl_api_sw_interface_set_vxlan_gbp_bypass_t_handler
  (vl_api_sw_interface_set_vxlan_gbp_bypass_t * mp)
{
  vl_api_sw_interface_set_vxlan_gbp_bypass_reply_t *rmp;
  int rv = 0;
  u32 sw_if_index = ntohl (mp->sw_if_index);

  VALIDATE_SW_IF_INDEX (mp);

  vnet_int_vxlan_gbp_bypass_mode (sw_if_index, mp->is_ipv6, mp->enable);
  BAD_SW_IF_INDEX_LABEL;

  REPLY_MACRO (VL_API_SW_INTERFACE_SET_VXLAN_GBP_BYPASS_REPLY);
}

static int
vxlan_gbp_tunnel_mode_decode (vl_api_vxlan_gbp_api_tunnel_mode_t in,
			      vxlan_gbp_tunnel_mode_t * out)
{
  in = clib_net_to_host_u32 (in);

  switch (in)
    {
    case VXLAN_GBP_API_TUNNEL_MODE_L2:
      *out = VXLAN_GBP_TUNNEL_MODE_L2;
      return (0);
    case VXLAN_GBP_API_TUNNEL_MODE_L3:
      *out = VXLAN_GBP_TUNNEL_MODE_L3;
      return (0);
    }
  return (VNET_API_ERROR_INVALID_VALUE);
}

static void vl_api_vxlan_gbp_tunnel_add_del_t_handler
  (vl_api_vxlan_gbp_tunnel_add_del_t * mp)
{
  vl_api_vxlan_gbp_tunnel_add_del_reply_t *rmp;
  vxlan_gbp_tunnel_mode_t mode;
  ip46_address_t src, dst;
  ip46_type_t itype;
  int rv = 0;
  u32 sw_if_index = ~0;
  u32 fib_index;

  itype = ip_address_decode (&mp->tunnel.src, &src);
  itype = ip_address_decode (&mp->tunnel.dst, &dst);

  fib_index = fib_table_find (fib_proto_from_ip46 (itype),
			      ntohl (mp->tunnel.encap_table_id));
  if (fib_index == ~0)
    {
      rv = VNET_API_ERROR_NO_SUCH_FIB;
      goto out;
    }

  rv = vxlan_gbp_tunnel_mode_decode (mp->tunnel.mode, &mode);

  if (rv)
    goto out;

  vnet_vxlan_gbp_tunnel_add_del_args_t a = {
    .is_add = mp->is_add,
    .is_ip6 = (itype == IP46_TYPE_IP6),
    .instance = ntohl (mp->tunnel.instance),
    .mcast_sw_if_index = ntohl (mp->tunnel.mcast_sw_if_index),
    .encap_fib_index = fib_index,
    .vni = ntohl (mp->tunnel.vni),
    .dst = dst,
    .src = src,
    .mode = mode,
  };

  /* Check src & dst are different */
  if (ip46_address_cmp (&a.dst, &a.src) == 0)
    {
      rv = VNET_API_ERROR_SAME_SRC_DST;
      goto out;
    }
  if (ip46_address_is_multicast (&a.dst) &&
      !vnet_sw_if_index_is_api_valid (a.mcast_sw_if_index))
    {
      rv = VNET_API_ERROR_INVALID_SW_IF_INDEX;
      goto out;
    }

  rv = vnet_vxlan_gbp_tunnel_add_del (&a, &sw_if_index);

out:
  /* *INDENT-OFF* */
  REPLY_MACRO2(VL_API_VXLAN_GBP_TUNNEL_ADD_DEL_REPLY,
  ({
    rmp->sw_if_index = ntohl (sw_if_index);
  }));
  /* *INDENT-ON* */
}

static void send_vxlan_gbp_tunnel_details
  (vxlan_gbp_tunnel_t * t, vl_api_registration_t * reg, u32 context)
{
  vl_api_vxlan_gbp_tunnel_details_t *rmp;
  ip46_type_t itype = (ip46_address_is_ip4 (&t->dst) ?
		       IP46_TYPE_IP4 : IP46_TYPE_IP6);

  rmp = vl_msg_api_alloc (sizeof (*rmp));
  clib_memset (rmp, 0, sizeof (*rmp));
  rmp->_vl_msg_id =
    ntohs (VL_API_VXLAN_GBP_TUNNEL_DETAILS + REPLY_MSG_ID_BASE);

  ip_address_encode (&t->src, itype, &rmp->tunnel.src);
  ip_address_encode (&t->dst, itype, &rmp->tunnel.dst);
  rmp->tunnel.encap_table_id =
    fib_table_get_table_id (t->encap_fib_index, fib_proto_from_ip46 (itype));

  rmp->tunnel.instance = htonl (t->user_instance);
  rmp->tunnel.mcast_sw_if_index = htonl (t->mcast_sw_if_index);
  rmp->tunnel.vni = htonl (t->vni);
  rmp->tunnel.sw_if_index = htonl (t->sw_if_index);
  rmp->context = context;

  vl_api_send_msg (reg, (u8 *) rmp);
}

static void vl_api_vxlan_gbp_tunnel_dump_t_handler
  (vl_api_vxlan_gbp_tunnel_dump_t * mp)
{
  vl_api_registration_t *reg;
  vxlan_gbp_main_t *vxm = &vxlan_gbp_main;
  vxlan_gbp_tunnel_t *t;
  u32 sw_if_index;

  reg = vl_api_client_index_to_registration (mp->client_index);
  if (!reg)
    return;

  sw_if_index = ntohl (mp->sw_if_index);

  if (~0 == sw_if_index)
    {
      /* *INDENT-OFF* */
      pool_foreach (t, vxm->tunnels)
       {
        send_vxlan_gbp_tunnel_details(t, reg, mp->context);
      }
      /* *INDENT-ON* */
    }
  else
    {
      if ((sw_if_index >= vec_len (vxm->tunnel_index_by_sw_if_index)) ||
	  (~0 == vxm->tunnel_index_by_sw_if_index[sw_if_index]))
	{
	  return;
	}
      t = &vxm->tunnels[vxm->tunnel_index_by_sw_if_index[sw_if_index]];
      send_vxlan_gbp_tunnel_details (t, reg, mp->context);
    }
}

#include <vxlan-gbp/vxlan_gbp.api.c>
static clib_error_t *
vxlan_gbp_api_hookup (vlib_main_t * vm)
{
  /*
   * Set up the (msg_name, crc, message-id) table
   */
  msg_id_base = setup_message_id_table ();

  return 0;
}

VLIB_API_INIT_FUNCTION (vxlan_gbp_api_hookup);

/*
 * fd.io coding-style-patch-verification: ON
 *
 * Local Variables:
 * eval: (c-set-style "gnu")
 * End:
 */
