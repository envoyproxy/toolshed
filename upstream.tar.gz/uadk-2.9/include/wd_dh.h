/* SPDX-License-Identifier: Apache-2.0 */
/*
 * Copyright 2020-2021 Huawei Technologies Co.,Ltd. All rights reserved.
 * Copyright 2020-2021 Linaro ltd.
 */

#ifndef __WD_DH_H
#define __WD_DH_H

#include <stdbool.h>

#include "wd_alg_common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*wd_dh_cb_t)(void *cb_param);

enum wd_dh_op_type {
	WD_DH_INVALID, /* invalid DH operation */
	WD_DH_PHASE1, /* Phase1 DH key generate */
	WD_DH_PHASE2 /* Phase2 DH key compute */
};

struct wd_dh_sess_setup {
	__u16 key_bits; /* DH key bites */
	bool is_g2; /* is g2 mode or not */
	void *sched_param;
};

struct wd_dh_req {
	void *x_p; /* x and p */

	/* it is g, but it is PV at phase 2 */
	void *pv;

	/* phase 1&&2 output */
	void *pri;
	__u16 pri_bytes; /* output bytes */

	__u16 pbytes; /* p bytes */
	__u16 xbytes; /* x bytes */
	__u16 pvbytes; /* pv bytes */
	wd_dh_cb_t cb;
	void *cb_param;
	int status; /* output status */
	__u8 op_type; /* operational type */
	__u8 data_fmt; /* data format denoted by enum wd_buff_type */
};

int wd_dh_get_mode(handle_t sess, __u8 *alg_mode);
__u32 wd_dh_key_bits(handle_t sess);
int wd_dh_set_g(handle_t sess, struct wd_dtb *g);
void wd_dh_get_g(handle_t sess, struct wd_dtb **g);
handle_t wd_dh_alloc_sess(struct wd_dh_sess_setup *setup);
void wd_dh_free_sess(handle_t sess);
int wd_do_dh_async(handle_t sess, struct wd_dh_req *req);
int wd_do_dh_sync(handle_t sess, struct wd_dh_req *req);
int wd_dh_poll_ctx(__u32 idx, __u32 expt, __u32 *count);
int wd_dh_poll(__u32 expt, __u32 *count);
int wd_dh_init(struct wd_ctx_config *config, struct wd_sched *sched);
void wd_dh_uninit(void);

/**
 * wd_dh_init2_() - A simplify interface to initializate dh.
 * This interface keeps most functions of
 * wd_dh_init(). Users just need to descripe the deployment of
 * business scenarios. Then the initialization will request appropriate
 * resources to support the business scenarios.
 * To make the initializate simpler, ctx_params support set NULL.
 * And then the function will set them as default.
 * Please do not use this interface with wd_dh_init() together, or
 * some resources may be leak.
 *
 * @alg: The algorithm users want to use.
 * @sched_type: The scheduling type users want to use.
 * @task_type: Reserved.
 * @ctx_params: The ctxs resources users want to use. Include per operation
 * type ctx numbers and business process run numa.
 *
 * Return 0 if succeed and others if fail.
 */
int wd_dh_init2_(char *alg, __u32 sched_type, int task_type, struct wd_ctx_params *ctx_params);

#define wd_dh_init2(alg, sched_type, task_type) \
	wd_dh_init2_(alg, sched_type, task_type, NULL)

/**
 * wd_dh_uninit2() - Uninitialise ctx configuration and scheduler.
 */
void wd_dh_uninit2(void);

int wd_dh_env_init(struct wd_sched *sched);
void wd_dh_env_uninit(void);
int wd_dh_ctx_num_init(__u32 node, __u32 type, __u32 num, __u8 mode);
void wd_dh_ctx_num_uninit(void);
int wd_dh_get_env_param(__u32 node, __u32 type, __u32 mode,
			__u32 *num, __u8 *is_enable);

#ifdef __cplusplus
}
#endif

#endif /* __WD_DH_H */
