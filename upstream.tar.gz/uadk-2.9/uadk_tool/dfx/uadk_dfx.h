/* SPDX-License-Identifier: Apache-2.0 */
#ifndef UADK_DFX_H
#define UADK_DFX_H

void print_dfx_help(void);
void dfx_cmd_parse(int argc, char *argv[]);
#endif
