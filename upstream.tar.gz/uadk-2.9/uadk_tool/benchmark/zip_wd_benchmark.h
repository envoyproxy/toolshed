/* SPDX-License-Identifier: Apache-2.0 */
#ifndef ZIP_WD_BENCHMARK_H
#define ZIP_WD_BENCHMARK_H

extern int zip_wd_benchmark(struct acc_option *options);
#endif /* ZIP_WD_BENCHMARK_H */
