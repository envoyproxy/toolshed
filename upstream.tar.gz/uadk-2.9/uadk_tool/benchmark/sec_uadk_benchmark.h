/* SPDX-License-Identifier: Apache-2.0 */
#ifndef SEC_UADK_BENCHMARK_H
#define SEC_UADK_BENCHMARK_H

extern int sec_uadk_benchmark(struct acc_option *options);
#endif /* SEC_UADK_BENCHMARK_H */
