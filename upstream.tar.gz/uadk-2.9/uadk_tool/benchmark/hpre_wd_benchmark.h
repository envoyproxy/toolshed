/* SPDX-License-Identifier: Apache-2.0 */
#ifndef HPRE_WD_BENCHMARK_H
#define HPRE_WD_BENCHMARK_H

extern int hpre_wd_benchmark(struct acc_option *options);
#endif /* HPRE_WD_BENCHMARK_H */
