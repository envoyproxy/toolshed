/* SPDX-License-Identifier: Apache-2.0 */
#ifndef SEC_SOFT_BENCHMARK_H
#define SEC_SOFT_BENCHMARK_H

#include "uadk_benchmark.h"

extern int sec_soft_benchmark(struct acc_option *options);
#endif /* SEC_SOFT_BENCHMARK_H */
