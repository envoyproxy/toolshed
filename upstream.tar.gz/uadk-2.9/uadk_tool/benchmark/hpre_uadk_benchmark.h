/* SPDX-License-Identifier: Apache-2.0 */
#ifndef HPRE_UADK_BENCHMARK_H
#define HPRE_UADK_BENCHMARK_H

extern int hpre_uadk_benchmark(struct acc_option *options);
#endif /* HPRE_UADK_BENCHMARK_H */
