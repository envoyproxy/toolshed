/* SPDX-License-Identifier: Apache-2.0 */
#ifndef ZIP_UADK_BENCHMARK_H
#define ZIP_UADK_BENCHMARK_H

extern int zip_uadk_benchmark(struct acc_option *options);
#endif /* ZIP_UADK_BENCHMARK_H */
