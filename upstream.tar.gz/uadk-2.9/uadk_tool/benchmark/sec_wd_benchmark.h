/* SPDX-License-Identifier: Apache-2.0 */
#ifndef SEC_WD_BENCHMARK_H
#define SEC_WD_BENCHMARK_H

#include "uadk_benchmark.h"

extern int sec_wd_benchmark(struct acc_option *options);
#endif /* SEC_WD_BENCHMARK_H */
