/* SPDX-License-Identifier: Apache-2.0 */
#ifndef UADK_TEST_H
#define UADK_TEST_H

void print_test_help(void);
void acc_test_run(int argc, char *argv[]);
#endif

