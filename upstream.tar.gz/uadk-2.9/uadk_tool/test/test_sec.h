/* SPDX-License-Identifier: Apache-2.0 */

#ifndef TEST_SEC_H
#define TEST_SEC_H


int test_sec_entry(int argc, char *argv[]);

#endif /* TEST_SEC_H */

