/* SPDX-License-Identifier: Apache-2.0 */
/*
 * Copyright 2024 Huawei Technologies Co.,Ltd. All rights reserved.
 */

#ifndef TEST_COMP_H
#define TEST_COMP_H

int test_comp_entry(int argc, char *argv[]);

#endif /* TEST_COMP_H */