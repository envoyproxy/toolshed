# Contributing to Wasmtime and/or Cranelift

Wasmtime and Cranelift are [Bytecode Alliance] projects. They follow the
Bytecode Alliance's [Code of Conduct] and [Organizational Code of Conduct].

For more information about contributing to these projects you can consult the
[online documentation] which should cover all sorts of topics.

[Bytecode Alliance]: https://bytecodealliance.org/
[Code of Conduct]: CODE_OF_CONDUCT.md
[Organizational Code of Conduct]: ORG_CODE_OF_CONDUCT.md
[online documentation]: https://bytecodealliance.github.io/wasmtime/contributing.html
