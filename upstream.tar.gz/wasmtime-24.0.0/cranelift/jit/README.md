This crate provides a JIT library that uses
[Cranelift](https://crates.io/crates/cranelift).

This crate is extremely experimental.

See the [example program] for a brief overview of how to use this.

[example program]: https://github.com/bytecodealliance/wasmtime/blob/main/cranelift/jit/examples/jit-minimal.rs
