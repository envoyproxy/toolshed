This crate provides an interpreter for Cranelift IR. It is still a work in progress, as many
instructions are unimplemented and various implementation gaps exist. Use at your own risk.
