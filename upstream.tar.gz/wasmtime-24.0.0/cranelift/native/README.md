This crate performs autodetection of the host architecture, which can be used to
configure [Cranelift](https://crates.io/crates/cranelift) to generate code
specialized for the machine it's running on.
