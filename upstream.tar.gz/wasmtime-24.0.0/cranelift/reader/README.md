This crate library supports reading .clif files. This functionality is needed
for testing [Cranelift](https://crates.io/crates/cranelift), but is not essential
for a JIT compiler.
