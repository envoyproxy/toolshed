# `cranelift-fuzzgen`

This crate implements a generator to create random Cranelift modules.
