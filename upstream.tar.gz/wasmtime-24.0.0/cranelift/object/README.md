This crate contains a library that enables
[Cranelift](https://crates.io/crates/cranelift)
to emit native object (".o") files, using the
[object](https://crates.io/crates/object) library.
