# ISLE Fuzz Targets

These are separate from the top-level `wasmtime/fuzz` fuzz targets because we
don't intend to run them on OSS-Fuzz. They are just for local ISLE hacking.
