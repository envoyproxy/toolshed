This crate contains shared definitions for use in both `cranelift-codegen-meta` and `cranelift
-codegen`.
