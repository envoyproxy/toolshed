This is an umbrella crate which contains no code of its own, but pulls in
other cranelift library crates to provide a convenient one-line dependency,
and a prelude, for common use cases.
