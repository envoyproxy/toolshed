---
name: Wasmtime Bug Report
about: Report a bug or a crash in Wasmtime
title: ''
labels: bug
assignees: ''

---

Thanks for filing a bug report! Please fill out the TODOs below.

**Note: if you want to report a security issue, please read our [security policy](https://bytecodealliance.org/security)!**

### Test Case

TODO: upload Wasm file here

### Steps to Reproduce

* TODO: first, ...
* TODO: second, ...
* Etc...

### Expected Results

TODO: What do you expect to happen?

### Actual Results

TODO: What actually happens? Panic? Segfault? Incorrect result?

### Versions and Environment

Wasmtime version or commit: TODO

Operating system: TODO

Architecture: TODO

### Extra Info

Anything else you'd like to add?
